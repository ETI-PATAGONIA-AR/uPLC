#==================================================================
# uPLC_v3/gui/main_window.py - ETI Patagonia - prof.martintorres@educ.ar
#==================================================================

import os
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QSplitter,
    QToolBar, QAction, QFileDialog, QMessageBox, QStatusBar, QInputDialog,
)
from PyQt5.QtGui import QIcon, QKeySequence
from PyQt5.QtCore import Qt

from core.model import LadderModel
from gui.canvas import LadderCanvas
from gui.toolbox import Toolbox
from gui.sketch_dialog import SketchDialog
from generator.sketch_builder import build_sketch
from project.project_io import save_project, load_project, project_name_from_path


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("uPLCv3 — ETI Patagonia")
        self.setGeometry(80, 60, 1280, 750)
        self._current_file = None
        self._model = LadderModel()

        self._build_ui()
        self._build_menus()
        self._build_toolbar()
        self._update_title()

    # ─── Construcción de la interfaz ──────────────────────────────
    def _build_ui(self):
        # Splitter principal: Toolbox | Canvas
        splitter = QSplitter(Qt.Horizontal)
        self.setCentralWidget(splitter)

        self._toolbox = Toolbox()
        self._toolbox.tool_selected.connect(self._on_tool_selected)
        splitter.addWidget(self._toolbox)

        self._canvas = LadderCanvas(self._model)
        self._canvas.model_changed.connect(self._on_model_changed)
        splitter.addWidget(self._canvas)

        splitter.setSizes([200, 1000])
        splitter.setStretchFactor(1, 1)

        # Barra de estado
        self._status = QStatusBar()
        self.setStatusBar(self._status)
        self._status.showMessage("Listo — seleccioná una función del panel y hacé clic en el canvas")

    # ─── Menú ─────────────────────────────────────────────────────
    def _build_menus(self):
        mb = self.menuBar()

        # Archivo
        m_file = mb.addMenu("Archivo")
        m_file.addAction("Nuevo", self._new_project, QKeySequence.New)
        m_file.addAction("Abrir...", self._open_project, QKeySequence.Open)
        m_file.addAction("Guardar", self._save_project, QKeySequence.Save)
        m_file.addAction("Guardar como...", self._save_as, QKeySequence("Ctrl+Shift+S"))
        m_file.addSeparator()
        m_file.addAction("Salir", self.close)

        # Editar
        m_edit = mb.addMenu("Editar")
        m_edit.addAction("Nombre del proyecto...", self._edit_project_name)
        m_edit.addSeparator()
        m_edit.addAction("Agregar Rung", self._add_rung, QKeySequence("Ctrl+R"))

        # Generar
        m_gen = mb.addMenu("Generar")
        m_gen.addAction("Ver Sketch Arduino", self._gen_sketch, QKeySequence("Ctrl+G"))

        # Ayuda
        m_help = mb.addMenu("Ayuda")
        m_help.addAction("Acerca de...", self._about)

    # ─── Toolbar ──────────────────────────────────────────────────
    def _build_toolbar(self):
        tb = QToolBar("Principal")
        tb.setMovable(False)
        self.addToolBar(tb)

        a_new = QAction("Nuevo", self)
        a_new.triggered.connect(self._new_project)
        tb.addAction(a_new)

        a_open = QAction("Abrir", self)
        a_open.triggered.connect(self._open_project)
        tb.addAction(a_open)

        a_save = QAction("Guardar", self)
        a_save.triggered.connect(self._save_project)
        tb.addAction(a_save)

        tb.addSeparator()

        a_rung = QAction("＋ Agregar Rung", self)
        a_rung.triggered.connect(self._add_rung)
        tb.addAction(a_rung)

        tb.addSeparator()

        a_gen = QAction("⚡ Generar Sketch", self)
        a_gen.setToolTip("Generar y ver el sketch Arduino (Ctrl+G)")
        a_gen.triggered.connect(self._gen_sketch)
        tb.addAction(a_gen)

    # ─── Slots ───────────────────────────────────────────────────
    def _on_tool_selected(self, tool: str):
        self._canvas.set_active_tool(tool)
        if tool:
            from config.constants import TOOL_LABELS
            self._status.showMessage(
                f"Herramienta: {TOOL_LABELS.get(tool, tool)} — "
                f"Clic en celda de condición / zona de salida para colocar"
            )
        else:
            self._status.showMessage("Modo cursor — Clic derecho sobre un bloque para asignar referencia")

    def _on_model_changed(self):
        self._update_title(modified=True)

    def _add_rung(self):
        self._canvas.add_rung()
        self._status.showMessage("Rung agregado")

    # ─── Proyecto ────────────────────────────────────────────────
    def _new_project(self):
        if not self._confirm_discard():
            return
        self._model = LadderModel()
        self._current_file = None
        self._canvas.set_model(self._model)
        self._update_title()
        self._status.showMessage("Proyecto nuevo creado")

    def _open_project(self):
        if not self._confirm_discard():
            return
        path, _ = QFileDialog.getOpenFileName(
            self, "Abrir proyecto", "", "Proyecto uPLC (*.uplc);;JSON (*.json)"
        )
        if not path:
            return
        m = load_project(path)
        if m is None:
            QMessageBox.critical(self, "Error", f"No se pudo cargar:\n{path}")
            return
        self._model = m
        self._current_file = path
        self._canvas.set_model(self._model)
        self._update_title()
        self._status.showMessage(f"Proyecto cargado: {path}")

    def _save_project(self):
        if not self._current_file:
            self._save_as()
            return
        ok = save_project(self._model, self._current_file)
        if ok:
            self._update_title()
            self._status.showMessage(f"Guardado: {self._current_file}")
        else:
            QMessageBox.critical(self, "Error", "No se pudo guardar el archivo.")

    def _save_as(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Guardar proyecto como", "", "Proyecto uPLC (*.uplc);;JSON (*.json)"
        )
        if not path:
            return
        if not path.endswith((".uplc", ".json")):
            path += ".uplc"
        ok = save_project(self._model, path)
        if ok:
            self._current_file = path
            self._model.project_name = project_name_from_path(path)
            self._update_title()
            self._status.showMessage(f"Guardado como: {path}")
        else:
            QMessageBox.critical(self, "Error", "No se pudo guardar el archivo.")

    def _edit_project_name(self):
        name, ok = QInputDialog.getText(
            self, "Nombre del proyecto", "Nombre:",
            text=self._model.project_name,
        )
        if ok and name.strip():
            self._model.project_name = name.strip()
            self._update_title()

    # ─── Generación de sketch ────────────────────────────────────
    def _gen_sketch(self):
        if not self._model.rungs:
            QMessageBox.information(
                self, "Sin rungs",
                "El programa no tiene rungs. Agregá al menos uno antes de generar."
            )
            return
        code = build_sketch(self._model)
        dlg = SketchDialog(code, self)
        dlg.exec_()

    # ─── Ayuda ───────────────────────────────────────────────────
    def _about(self):
        QMessageBox.about(
            self, "uPLCv3",
            "<b>uPLCv3 — Generador de Sketches Arduino Ladder</b><br>"
            "ETI Patagonia — prof.martintorres@educ.ar<br><br>"
            "https://eti-patagonia-ar.github.io/ETI-Patagonia-ARG/<br><br>"
            "<b>Hardware:</b> Arduino Nano<br>"
            "I1–I7: D2,D4–D9 | Q1–Q4: D14–D17 | Q5: D3 (PWM)<br>"
            "A0: A6 | A1: A7<br><br>"
            "<b>Uso rápido:</b><br>"
            "1. Seleccioná herramienta en el panel izquierdo<br>"
            "2. Clic izquierdo en celda de condición u zona de salida<br>"
            "3. Clic derecho sobre el bloque → Asignar Ref / Valor<br>"
            "4. Ctrl+G para generar el sketch"
        )

    # ─── Helpers ─────────────────────────────────────────────────
    def _update_title(self, modified=False):
        name = self._model.project_name or "Sin Nombre"
        mod  = " *" if modified else ""
        self.setWindowTitle(f"uPLCv3 — {name}{mod}   |   ETI Patagonia")

    def _confirm_discard(self) -> bool:
        """Retorna True si el usuario acepta descartar cambios (o no había nada)."""
        if not self._model.rungs:
            return True
        r = QMessageBox.question(
            self, "Descartar cambios",
            "¿Descartás el proyecto actual?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        return r == QMessageBox.Yes
