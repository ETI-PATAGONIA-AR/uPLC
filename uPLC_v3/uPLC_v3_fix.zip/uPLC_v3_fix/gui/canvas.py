#==================================================================
# uPLC_v3/gui/canvas.py - ETI Patagonia - prof.martintorres@educ.ar
#==================================================================

from PyQt5.QtWidgets import (
    QWidget, QScrollArea, QMenu, QInputDialog,
)
from PyQt5.QtGui import (
    QPainter, QPen, QBrush, QColor, QFont,
)
from PyQt5.QtCore import Qt, QRect, QSize, pyqtSignal

from config.constants import (
    NO, NC, ADC, CMP_GT, CMP_LT, CMP_EQ,
    COIL, COIL_NC, PWM, TON, TOFF, SET_VAR,
    OR_JCT, AND_JCT,
    OR_A, OR_B, AND_A, AND_B,
    CONDITION_TOOLS, OUTPUT_TOOLS,
    USER_PLACEABLE_COND,
    JUNCTION_TOOLS,
    VALID_REFS, VALUE_OPTIONS,
    CELL_W, CELL_H, MAX_COND, COMMENT_H,
    RAIL_X, LEFT_MARGIN, OUTPUT_X_OFF, OUTPUT_W,
    TOP_MARGIN, RUNG_GAP, ADD_BTN_H,
    RIGHT_RAIL_X, CANVAS_W,
    C_RAIL, C_WIRE, C_GRID, C_SELECTED,
    C_COMMENT, C_EMPTY_CELL, C_ADDBTN_BG,
    C_NO_BORDER, C_NC_BORDER, C_ADC_BORDER, C_CMP_BORDER,
    C_COIL_BG, C_COIL_BD, C_TON_BG, C_TON_BD,
    C_TOFF_BG, C_TOFF_BD, C_PWM_BG, C_PWM_BD,
    C_VAR_BG, C_VAR_BD,
)
from core.model import LadderModel, CellData


def _qc(rgb):
    return QColor(*rgb)

def _pen(rgb, w=2, s=Qt.SolidLine):
    return QPen(_qc(rgb), w, s)


# ──────────────────────────────────────────────────────────────────
class LadderWidget(QWidget):
    """
    Widget central del diagrama Ladder.
    Maneja dibujo, hit-testing e interacción con el modelo.
    """
    model_changed = pyqtSignal()

    F_SMALL = QFont("Arial", 8)
    F_BOLD  = QFont("Arial", 9, QFont.Bold)
    F_LABEL = QFont("Arial", 10, QFont.Bold)
    F_CMT   = QFont("Arial", 8, QFont.StyleItalic)

    def __init__(self, model: LadderModel, parent=None):
        super().__init__(parent)
        self.model         = model
        self._active_tool  = ""
        self._rung_tops    = []   # se actualiza en _compute_layout()
        self._sel          = None
        self._hover        = None
        self._add_btn_rect = QRect()
        self.setMouseTracking(True)
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._on_context_menu)

    # ── API pública ─────────────────────────────────────────────
    def set_active_tool(self, tool: str):
        self._active_tool = tool
        self._sel = None
        self.update()

    def set_model(self, model: LadderModel):
        self.model = model
        self._sel  = None
        self._refresh()

    # ── Layout ──────────────────────────────────────────────────
    def _compute_layout(self):
        self._rung_tops = []
        y = TOP_MARGIN
        for rung in self.model.rungs:
            self._rung_tops.append(y)
            y += rung.pixel_height() + RUNG_GAP
        self._canvas_h = max(y + ADD_BTN_H + 20, 200)

    def _branch_cy(self, ri: int, bi: int) -> int:
        """Y central de la rama bi del rung ri."""
        return (
            self._rung_tops[ri]
            + COMMENT_H
            + bi * CELL_H
            + CELL_H // 2
        )

    # ── Hit-test ────────────────────────────────────────────────
    def _hit_test(self, px: int, py: int):
        """
        Retorna una tupla que describe qué zona se clickeó:
          ("add_rung",  -1, -1, -1)
          ("comment",   ri, -1, -1)
          ("condition", ri, bi, col)
          ("output",    ri, -1, -1)
          None  → zona vacía entre rungs
        SIEMPRE llama _compute_layout() antes de buscar para asegurar
        que _rung_tops esté actualizado.
        """
        self._compute_layout()   # ← FIX del bug de segundo rung

        if self._add_btn_rect.contains(px, py):
            return ("add_rung", -1, -1, -1)

        for ri, rung in enumerate(self.model.rungs):
            rt = self._rung_tops[ri]
            rh = rung.pixel_height()

            if not (rt <= py < rt + rh):
                continue

            # Franja de comentario
            if py < rt + COMMENT_H:
                return ("comment", ri, -1, -1)

            # ¿Cuál branch?
            bi = (py - (rt + COMMENT_H)) // CELL_H
            if bi < 0 or bi >= len(rung.branches):
                continue

            # Zona de salida
            out_x = LEFT_MARGIN + MAX_COND * CELL_W + OUTPUT_X_OFF
            if out_x <= px < out_x + OUTPUT_W:
                return ("output", ri, -1, -1)

            # Zona de condición
            if LEFT_MARGIN <= px < LEFT_MARGIN + MAX_COND * CELL_W:
                col = (px - LEFT_MARGIN) // CELL_W
                return ("condition", ri, bi, col)

        return None

    # ── Mouse press ─────────────────────────────────────────────
    def mousePressEvent(self, event):
        if event.button() != Qt.LeftButton:
            return
        hit = self._hit_test(event.x(), event.y())
        if hit is None:
            return

        kind = hit[0]

        if kind == "add_rung":
            self.model.add_rung()
            self._refresh()
            return

        ri = hit[1]

        if kind == "comment":
            self._edit_comment(ri)
            return

        if not self._active_tool:
            # Sin herramienta → solo seleccionar
            self._sel = hit
            self.update()
            return

        # ── Herramienta activa ───────────────────────────────────

        if kind == "condition":
            bi, col = hit[2], hit[3]

            # Junction dual (OR_JCT / AND_JCT)
            if self._active_tool in (OR_JCT, AND_JCT):
                self._place_junction(ri, bi, col, self._active_tool)
                return

            # Condición simple
            if self._active_tool in USER_PLACEABLE_COND:
                cell = self.model.rungs[ri].branches[bi].cells[col]
                cell.tool  = self._active_tool
                cell.ref   = ""
                cell.value = ""
                self._sel  = hit
                self._refresh()

        elif kind == "output":
            if self._active_tool in OUTPUT_TOOLS:
                out = self.model.rungs[ri].output
                out.tool  = self._active_tool
                out.ref   = ""
                out.value = ""
                refs = VALID_REFS.get(self._active_tool, [])
                if len(refs) == 1:
                    out.ref = refs[0]
                self._sel = ("output", ri, -1, -1)
                self._refresh()

    def mouseMoveEvent(self, event):
        hit = self._hit_test(event.x(), event.y())
        if hit != self._hover:
            self._hover = hit
            self.update()

    # ── Lógica de junction dual ──────────────────────────────────
    def _place_junction(self, ri: int, bi: int, col: int, jct_tool: str):
        """
        Coloca OR_A/AND_A en (ri, bi, col) y OR_B/AND_B en (ri, bi+1, col).
        Si la rama bi+1 no existe, la crea automáticamente.
        """
        top_tool = OR_A  if jct_tool == OR_JCT  else AND_A
        bot_tool = OR_B  if jct_tool == OR_JCT  else AND_B

        rung = self.model.rungs[ri]

        # Asegurar que existe la rama bi+1
        if bi + 1 >= len(rung.branches):
            self.model.insert_branch_after(ri, bi)

        # Colocar mitad superior
        rung.branches[bi].cells[col].tool  = top_tool
        rung.branches[bi].cells[col].ref   = ""
        rung.branches[bi].cells[col].value = ""

        # Colocar mitad inferior
        rung.branches[bi + 1].cells[col].tool  = bot_tool
        rung.branches[bi + 1].cells[col].ref   = ""
        rung.branches[bi + 1].cells[col].value = ""

        self._sel = ("condition", ri, bi, col)
        self._refresh()

    # ── Menú contextual ─────────────────────────────────────────
    def _on_context_menu(self, pos):
        hit = self._hit_test(pos.x(), pos.y())
        if hit is None:
            return

        kind, ri = hit[0], hit[1]
        menu = QMenu(self)

        if kind == "condition":
            bi, col = hit[2], hit[3]
            cell = self.model.rungs[ri].branches[bi].cells[col]
            if not cell.is_empty() and cell.tool not in JUNCTION_TOOLS:
                self._add_ref_menu(menu, cell,
                    lambda r, _ri=ri, _bi=bi, _col=col: self._set_cond_ref(_ri, _bi, _col, r))
                self._add_val_menu(menu, cell,
                    lambda v, _ri=ri, _bi=bi, _col=col: self._set_cond_val(_ri, _bi, _col, v))
                menu.addSeparator()
            if not cell.is_empty():
                act = menu.addAction("🗑  Borrar bloque")
                act.triggered.connect(
                    lambda checked=False, _ri=ri, _bi=bi, _col=col:
                        self._clear_cond(_ri, _bi, _col)
                )

        elif kind == "output":
            out = self.model.rungs[ri].output
            if not out.is_empty():
                self._add_ref_menu(menu, out,
                    lambda r, _ri=ri: self._set_out_ref(_ri, r))
                if out.tool in (TON, TOFF):
                    act = menu.addAction("⏱  Cambiar tiempo (ms)...")
                    act.triggered.connect(
                        lambda checked=False, _ri=ri: self._edit_timer_ms(_ri)
                    )
                self._add_val_menu(menu, out,
                    lambda v, _ri=ri: self._set_out_val(_ri, v))
                menu.addSeparator()
                act = menu.addAction("🗑  Borrar salida")
                act.triggered.connect(
                    lambda checked=False, _ri=ri: self._clear_output(_ri)
                )

        elif kind == "comment":
            act = menu.addAction("✏  Editar comentario...")
            act.triggered.connect(
                lambda checked=False, _ri=ri: self._edit_comment(_ri)
            )

        # Acciones de rung siempre disponibles
        if ri >= 0:
            menu.addSeparator()
            act = menu.addAction("➕  Insertar Rung debajo")
            act.triggered.connect(
                lambda checked=False, _ri=ri: self._insert_rung(_ri)
            )
            if kind == "condition":
                bi = hit[2]
                n_branches = len(self.model.rungs[ri].branches)
                if n_branches > 1:
                    act2 = menu.addAction("➖  Eliminar esta Rama")
                    act2.triggered.connect(
                        lambda checked=False, _ri=ri, _bi=bi: self._del_branch(_ri, _bi)
                    )
            act3 = menu.addAction("🗑  Eliminar Rung")
            act3.triggered.connect(
                lambda checked=False, _ri=ri: self._del_rung(_ri)
            )

        if menu.actions():
            menu.exec_(self.mapToGlobal(pos))

    def _add_ref_menu(self, menu: QMenu, cell: CellData, setter):
        refs = VALID_REFS.get(cell.tool, [])
        if not refs:
            return
        sub = menu.addMenu(f"Asignar Ref  [{cell.ref or '—'}]")
        for r in refs:
            act = sub.addAction(r)
            act.triggered.connect(lambda checked=False, rv=r: setter(rv))

    def _add_val_menu(self, menu: QMenu, cell: CellData, setter):
        opts = VALUE_OPTIONS.get(cell.tool, [])
        if not opts:
            return
        sub = menu.addMenu(f"Asignar Valor  [{cell.value or '—'}]")
        for v in opts:
            act = sub.addAction(v)
            act.triggered.connect(lambda checked=False, vv=v: setter(vv))

    # ── Mutaciones ──────────────────────────────────────────────
    def _set_cond_ref(self, ri, bi, col, ref):
        self.model.rungs[ri].branches[bi].cells[col].ref = ref
        self._refresh()

    def _set_cond_val(self, ri, bi, col, val):
        self.model.rungs[ri].branches[bi].cells[col].value = val
        self._refresh()

    def _set_out_ref(self, ri, ref):
        self.model.rungs[ri].output.ref = ref
        self._refresh()

    def _set_out_val(self, ri, val):
        self.model.rungs[ri].output.value = val
        self._refresh()

    def _clear_cond(self, ri, bi, col):
        self.model.rungs[ri].branches[bi].cells[col] = CellData()
        self._refresh()

    def _clear_output(self, ri):
        self.model.rungs[ri].output = CellData()
        self._refresh()

    def _del_branch(self, ri, bi):
        self.model.delete_branch(ri, bi)
        self._refresh()

    def _del_rung(self, ri):
        self.model.delete_rung(ri)
        self._sel = None
        self._refresh()

    def _insert_rung(self, ri):
        self.model.insert_rung(ri)
        self._refresh()

    def _edit_comment(self, ri):
        text, ok = QInputDialog.getText(
            self, "Comentario",
            "Texto del comentario:",
            text=self.model.rungs[ri].comment,
        )
        if ok:
            self.model.rungs[ri].comment = text
            self._refresh()

    def _edit_timer_ms(self, ri):
        out = self.model.rungs[ri].output
        val, ok = QInputDialog.getInt(
            self, "Temporizador",
            "Tiempo en milisegundos:",
            value=int(out.value) if out.value else 1000,
            min=1, max=3600000,
        )
        if ok:
            out.value = str(val)
            self._refresh()

    def _refresh(self):
        self._compute_layout()
        w = max(CANVAS_W + 10, self.width())
        self.setMinimumSize(w, self._canvas_h)
        self.resize(w, self._canvas_h)
        self.update()
        self.model_changed.emit()

    # ── Pintado principal ────────────────────────────────────────
    def paintEvent(self, event):
        self._compute_layout()
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.fillRect(self.rect(), QColor(255, 255, 255))

        if not self.model.rungs:
            self._draw_hint(p)
        else:
            for ri, rung in enumerate(self.model.rungs):
                self._draw_rung(p, ri, rung)

        self._draw_add_btn(p)

    def _draw_hint(self, p):
        p.setPen(_pen(C_GRID))
        p.setFont(QFont("Arial", 13))
        p.drawText(QRect(0, 60, CANVAS_W, 80), Qt.AlignCenter,
                   "Presioná  ＋ Agregar Rung  para comenzar")

    # ── Dibujo de un rung completo ───────────────────────────────
    def _draw_rung(self, p, ri: int, rung):
        rt       = self._rung_tops[ri]
        n_br     = len(rung.branches)
        rung_h   = rung.pixel_height()
        rail_top = rt + COMMENT_H
        rail_bot = rt + rung_h

        # Franja comentario
        cmt_r = QRect(RAIL_X, rt, RIGHT_RAIL_X - RAIL_X + 14, COMMENT_H)
        p.fillRect(cmt_r, _qc(C_COMMENT))
        p.setPen(_pen(C_GRID, 1))
        p.drawRect(cmt_r)
        p.setFont(self.F_CMT)
        p.setPen(QColor(80, 100, 60))
        cmt_txt = f"// {rung.comment}" if rung.comment else f"// Rung {ri + 1}"
        p.drawText(QRect(RAIL_X + 6, rt + 3, 600, COMMENT_H - 4), Qt.AlignVCenter, cmt_txt)

        # Carriles de potencia (izquierdo y derecho)
        p.setPen(_pen(C_RAIL, 5))
        p.drawLine(RAIL_X,      rail_top, RAIL_X,      rail_bot)
        p.drawLine(RIGHT_RAIL_X, rail_top, RIGHT_RAIL_X, rail_bot)

        # Y central de cada rama
        branch_cys = [self._branch_cy(ri, bi) for bi in range(n_br)]

        # Junción izquierda (OR) — barra vertical uniendo todas las ramas
        if n_br > 1:
            p.setPen(_pen(C_WIRE, 2))
            p.drawLine(LEFT_MARGIN - 2, branch_cys[0],
                       LEFT_MARGIN - 2, branch_cys[-1])

        # Junción derecha — barra vertical antes de la salida
        jct_x = LEFT_MARGIN + MAX_COND * CELL_W + OUTPUT_X_OFF - 10
        if n_br > 1:
            p.setPen(_pen(C_WIRE, 2))
            p.drawLine(jct_x, branch_cys[0], jct_x, branch_cys[-1])

        # Y de la salida = centroide de todas las ramas
        out_cy = (branch_cys[0] + branch_cys[-1]) // 2

        # Dibujar cada rama
        for bi in range(n_br):
            self._draw_branch(p, ri, bi, branch_cys[bi], rung.branches[bi], jct_x)

        # Hilo junción → salida
        out_x = LEFT_MARGIN + MAX_COND * CELL_W + OUTPUT_X_OFF
        p.setPen(_pen(C_WIRE, 2))
        p.drawLine(jct_x, out_cy, out_x, out_cy)

        # Celda de salida
        is_sel = self._sel and self._sel[:2] == ("output", ri)
        is_hov = self._hover and self._hover[:2] == ("output", ri)
        self._draw_output(p, out_x, out_cy, rung.output, bool(is_sel), bool(is_hov))

        # Hilo salida → carril derecho
        p.setPen(_pen(C_WIRE, 2))
        p.drawLine(out_x + OUTPUT_W, out_cy, RIGHT_RAIL_X, out_cy)

    # ── Dibujo de una rama ───────────────────────────────────────
    def _draw_branch(self, p, ri, bi, by, branch, jct_x):
        # Hilo carril izq → primera celda
        p.setPen(_pen(C_WIRE, 2))
        p.drawLine(RAIL_X, by, LEFT_MARGIN, by)

        for col in range(MAX_COND):
            cx   = LEFT_MARGIN + col * CELL_W
            cell = branch.cells[col]
            is_sel = self._sel == ("condition", ri, bi, col)
            is_hov = self._hover == ("condition", ri, bi, col)
            self._draw_cond_cell(p, cx, by, cell, is_sel, is_hov)

        # Hilo última celda → junción
        p.setPen(_pen(C_WIRE, 2))
        p.drawLine(LEFT_MARGIN + MAX_COND * CELL_W, by, jct_x, by)

    # ── Dibujo de celda de condición ─────────────────────────────
    def _draw_cond_cell(self, p, cx, cy, cell: CellData, selected, hovered):
        cw = CELL_W
        ch = CELL_H
        cell_rect = QRect(cx + 2, cy - ch // 2 + 2, cw - 4, ch - 4)

        # ── Celda vacía ──────────────────────────────────────────
        if cell.is_empty():
            bg = _qc(C_EMPTY_CELL) if hovered else QColor(248, 250, 255)
            p.fillRect(cell_rect, bg)
            p.setPen(_pen(C_GRID, 1, Qt.DashLine))
            p.drawRect(cell_rect)
            p.setPen(_pen(C_WIRE, 2))
            p.drawLine(cx, cy, cx + cw, cy)
            return

        tool   = cell.tool
        mid_x  = cx + cw // 2

        # ── Junction dual: dibujado con QPainter (BUG #3 FIX) ──────
        #
        #  OR_A / AND_A  (mitad SUPERIOR)
        #  ─────────────────────────────
        #  Hilo izq → bloque con etiqueta → hilo der
        #  Línea vertical hacia abajo en el borde derecho
        #  indicando la unión con la mitad inferior
        #
        #  OR_B / AND_B  (mitad INFERIOR)
        #  ─────────────────────────────
        #  Hilo izq → hilo derecho (sin bloque)
        #  Línea vertical desde arriba en el borde derecho
        #  que se une con la mitad superior
        #
        if tool in JUNCTION_TOOLS:
            is_top = tool in (OR_A, AND_A)
            lbl    = "OR"  if tool in (OR_A, OR_B)  else "AND"
            # Colores: OR = azul oscuro, AND = verde oscuro
            c_bd   = (20, 60, 160) if tool in (OR_A, OR_B) else (0, 110, 50)
            c_bg   = (220, 228, 255) if tool in (OR_A, OR_B) else (210, 245, 220)

            # Hilo de paso horizontal completo en ambas mitades
            p.setPen(_pen(C_WIRE, 2))
            p.drawLine(cx, cy, cx + cw, cy)

            top_y  = cy - ch // 2      # y borde superior de la celda
            bot_y  = cy + ch // 2      # y borde inferior de la celda
            right_x = cx + cw - 4      # x del conector vertical derecho

            if is_top:
                # Bloque con etiqueta
                bx = cx + 4
                bw = cw - 8
                bh = 28
                by = cy - bh // 2
                p.fillRect(QRect(bx, by, bw, bh), _qc(c_bg))
                p.setPen(QPen(_qc(c_bd), 2))
                p.drawRect(QRect(bx, by, bw, bh))
                p.setFont(self.F_BOLD)
                p.setPen(_qc(c_bd))
                p.drawText(QRect(bx, by, bw, bh), Qt.AlignCenter, lbl)
                # Línea vertical descendente en el lado derecho (unión con _B)
                p.setPen(QPen(_qc(c_bd), 2))
                p.drawLine(right_x, cy + bh // 2 + 1, right_x, bot_y)
            else:
                # Línea vertical ascendente en el lado derecho (unión con _A)
                p.setPen(QPen(_qc(c_bd), 2))
                p.drawLine(right_x, top_y, right_x, cy)

            if selected:
                p.setPen(QPen(_qc(C_SELECTED), 2, Qt.DashLine))
                p.setBrush(Qt.NoBrush)
                p.drawRect(QRect(cx + 1, cy - ch // 2 + 1, cw - 2, ch - 2))
            return

        # ── Hilo de paso para bloques normales ───────────────────
        p.setPen(_pen(C_WIRE, 2))
        p.drawLine(cx, cy, cx + cw, cy)

        # ── Contacto NO ─────────────────────────────────────────
        if tool == NO:
            gap = 12
            p.setPen(QPen(_qc(C_NO_BORDER), 3))
            p.drawLine(mid_x - gap, cy - 18, mid_x - gap, cy + 18)
            p.drawLine(mid_x + gap, cy - 18, mid_x + gap, cy + 18)

        # ── Contacto NC ─────────────────────────────────────────
        elif tool == NC:
            gap = 12
            p.setPen(QPen(_qc(C_NC_BORDER), 3))
            p.drawLine(mid_x - gap, cy - 18, mid_x - gap, cy + 18)
            p.drawLine(mid_x + gap, cy - 18, mid_x + gap, cy + 18)
            p.setPen(QPen(_qc(C_NC_BORDER), 2))
            p.drawLine(mid_x - gap - 5, cy + 20, mid_x + gap + 5, cy - 20)

        # ── ADC ─────────────────────────────────────────────────
        elif tool == ADC:
            r = QRect(mid_x - 22, cy - 16, 44, 32)
            p.fillRect(r, QColor(220, 255, 220))
            p.setPen(_pen(C_ADC_BORDER, 2))
            p.drawRect(r)
            p.setFont(self.F_BOLD)
            p.setPen(_qc(C_ADC_BORDER))
            p.drawText(r, Qt.AlignCenter, "ADC")

        # ── Comparadores ────────────────────────────────────────
        elif tool in (CMP_GT, CMP_LT, CMP_EQ):
            sym = {CMP_GT: ">", CMP_LT: "<", CMP_EQ: "="}[tool]
            r = QRect(mid_x - 22, cy - 16, 44, 32)
            p.fillRect(r, QColor(255, 240, 200))
            p.setPen(_pen(C_CMP_BORDER, 2))
            p.drawRect(r)
            p.setFont(self.F_LABEL)
            p.setPen(_qc(C_CMP_BORDER))
            p.drawText(r, Qt.AlignCenter, sym)

        # ── Etiquetas ref / valor ────────────────────────────────
        p.setFont(self.F_SMALL)
        p.setPen(QColor(30, 30, 120))
        if cell.ref:
            p.drawText(QRect(cx, cy + 20, cw, 16), Qt.AlignCenter, cell.ref)
        if cell.value:
            p.setFont(QFont("Arial", 7))
            p.setPen(QColor(90, 60, 0))
            p.drawText(QRect(cx, cy + 33, cw, 14), Qt.AlignCenter, cell.value)

        # ── Borde selección / hover ──────────────────────────────
        sel_rect = QRect(cx + 1, cy - ch // 2 + 1, cw - 2, ch - 2)
        if selected:
            p.setPen(QPen(_qc(C_SELECTED), 2, Qt.DashLine))
            p.setBrush(Qt.NoBrush)
            p.drawRect(sel_rect)
        elif hovered:
            p.setPen(QPen(QColor(100, 149, 237), 1, Qt.DashLine))
            p.setBrush(Qt.NoBrush)
            p.drawRect(sel_rect)

    # ── Dibujo de celda de salida ────────────────────────────────
    def _draw_output(self, p, ox, cy, cell: CellData, selected, hovered):
        mid_x    = ox + OUTPUT_W // 2
        cell_rect = QRect(ox, cy - CELL_H // 2 + 2, OUTPUT_W, CELL_H - 4)

        # Placeholder vacío
        if cell.is_empty():
            p.setPen(QPen(QColor(180, 180, 200), 1, Qt.DashLine))
            p.setBrush(Qt.NoBrush)
            r = 20
            p.drawEllipse(mid_x - r, cy - r, r * 2, r * 2)
            if hovered:
                p.fillRect(cell_rect, QColor(235, 240, 255, 100))
            return

        tool = cell.tool

        if tool in (COIL, COIL_NC):
            r = 22
            p.setBrush(QBrush(_qc(C_COIL_BG)))
            p.setPen(_pen(C_COIL_BD, 2))
            p.drawEllipse(mid_x - r, cy - r, r * 2, r * 2)
            if tool == COIL_NC:
                p.setPen(_pen(C_COIL_BD, 2))
                p.drawLine(mid_x - 14, cy + 14, mid_x + 14, cy - 14)
            p.setFont(self.F_BOLD)
            p.setPen(_qc(C_COIL_BD))
            if cell.ref:
                p.drawText(QRect(ox, cy + 26, OUTPUT_W, 16), Qt.AlignCenter, cell.ref)

        elif tool == PWM:
            r = QRect(mid_x - 26, cy - 19, 52, 38)
            p.fillRect(r, _qc(C_PWM_BG))
            p.setPen(_pen(C_PWM_BD, 2))
            p.drawRect(r)
            p.setFont(self.F_BOLD)
            p.setPen(_qc(C_PWM_BD))
            p.drawText(r, Qt.AlignCenter, "PWM")
            if cell.ref:
                p.setFont(self.F_SMALL)
                p.drawText(QRect(ox, cy + 22, OUTPUT_W, 14), Qt.AlignCenter, cell.ref)
            if cell.value:
                p.setFont(QFont("Arial", 7))
                p.setPen(QColor(100, 0, 0))
                p.drawText(QRect(ox, cy + 34, OUTPUT_W, 12), Qt.AlignCenter, f"← {cell.value}")

        elif tool in (TON, TOFF):
            bg  = C_TON_BG  if tool == TON  else C_TOFF_BG
            bd  = C_TON_BD  if tool == TON  else C_TOFF_BD
            lbl = "TON"     if tool == TON  else "TOF"
            r = QRect(mid_x - 26, cy - 19, 52, 38)
            p.fillRect(r, _qc(bg))
            p.setPen(_pen(bd, 2))
            p.drawRect(r)
            p.setFont(self.F_BOLD)
            p.setPen(_qc(bd))
            p.drawText(r, Qt.AlignCenter, lbl)
            if cell.ref:
                p.setFont(self.F_SMALL)
                p.setPen(_qc(bd))
                p.drawText(QRect(ox, cy + 22, OUTPUT_W, 14), Qt.AlignCenter, cell.ref)
            if cell.value:
                p.setFont(QFont("Arial", 7))
                p.setPen(QColor(0, 100, 0))
                p.drawText(QRect(ox, cy + 34, OUTPUT_W, 12), Qt.AlignCenter, f"{cell.value} ms")

        elif tool == SET_VAR:
            r = QRect(mid_x - 26, cy - 19, 52, 38)
            p.fillRect(r, _qc(C_VAR_BG))
            p.setPen(_pen(C_VAR_BD, 2))
            p.drawRect(r)
            p.setFont(self.F_BOLD)
            p.setPen(_qc(C_VAR_BD))
            p.drawText(r, Qt.AlignCenter, "SET")
            if cell.ref:
                p.setFont(self.F_SMALL)
                p.setPen(_qc(C_VAR_BD))
                txt = f"{cell.ref}={cell.value}" if cell.value else cell.ref
                p.drawText(QRect(ox, cy + 22, OUTPUT_W, 14), Qt.AlignCenter, txt)

        # Borde selección / hover
        sel_rect = QRect(ox + 1, cy - CELL_H // 2 + 3, OUTPUT_W - 2, CELL_H - 6)
        if selected:
            p.setPen(QPen(_qc(C_SELECTED), 2, Qt.DashLine))
            p.setBrush(Qt.NoBrush)
            p.drawRect(sel_rect)
        elif hovered:
            p.setPen(QPen(QColor(100, 149, 237), 1, Qt.DashLine))
            p.setBrush(Qt.NoBrush)
            p.drawRect(sel_rect)

    # ── Botón Agregar Rung ───────────────────────────────────────
    def _draw_add_btn(self, p):
        y = self._canvas_h - ADD_BTN_H - 8
        r = QRect(RAIL_X, y, RIGHT_RAIL_X - RAIL_X + 14, ADD_BTN_H - 4)
        self._add_btn_rect = r
        is_hov = self._hover and self._hover[0] == "add_rung"
        bg = QColor(200, 220, 255) if is_hov else _qc(C_ADDBTN_BG)
        p.fillRect(r, bg)
        p.setPen(_pen(C_RAIL, 1))
        p.drawRect(r)
        p.setFont(QFont("Arial", 11, QFont.Bold))
        p.setPen(_qc(C_RAIL))
        p.drawText(r, Qt.AlignCenter, "＋  Agregar Rung")

    def sizeHint(self):
        self._compute_layout()
        return QSize(CANVAS_W + 10, self._canvas_h)


# ──────────────────────────────────────────────────────────────────
class LadderCanvas(QScrollArea):
    """Scroll area que contiene el LadderWidget."""
    model_changed = pyqtSignal()

    def __init__(self, model: LadderModel, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setFrameShape(QScrollArea.StyledPanel)
        self._widget = LadderWidget(model, self)
        self._widget.model_changed.connect(self.model_changed)
        self.setWidget(self._widget)

    def set_active_tool(self, tool: str):
        self._widget.set_active_tool(tool)

    def set_model(self, model: LadderModel):
        self._widget.set_model(model)

    @property
    def model(self) -> LadderModel:
        return self._widget.model

    def add_rung(self):
        self._widget.model.add_rung()
        self._widget._refresh()
