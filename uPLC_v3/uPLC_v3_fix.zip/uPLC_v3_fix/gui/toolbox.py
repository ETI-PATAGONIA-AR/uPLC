#==================================================================
# uPLC_v3/gui/toolbox.py - ETI Patagonia - prof.martintorres@educ.ar
#==================================================================

import os
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton,
    QScrollArea, QGroupBox,
)
from PyQt5.QtGui import QIcon, QFont
from PyQt5.QtCore import Qt, QSize, pyqtSignal

from config.constants import (
    TOOLBOX_CATEGORIES, TOOL_LABELS, TOOL_ICONS,
    CONDITION_TOOLS, OUTPUT_TOOLS,
)

ICONS_DIR = os.path.join("assets", "icons")
BTN_H = 44
BTN_ICON = QSize(32, 32)


class Toolbox(QWidget):
    """
    Panel lateral izquierdo con las herramientas Ladder organizadas por categoría.
    Emite la señal tool_selected(str) cuando el usuario selecciona una herramienta.
    """
    tool_selected = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(200)
        self._active_tool = None
        self._buttons = {}

        root_layout = QVBoxLayout(self)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        # ── Título ─────────────────────────────────────────────────
        title = QLabel("  Funciones")
        title.setFixedHeight(32)
        title.setStyleSheet(
            "background:#1a3a6b; color:white; font-weight:bold; font-size:13px;"
        )
        root_layout.addWidget(title)

        # ── Scroll con categorías ──────────────────────────────────
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)

        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(4, 4, 4, 4)
        content_layout.setSpacing(4)

        for cat_name, tools in TOOLBOX_CATEGORIES:
            grp = QGroupBox(cat_name)
            grp.setStyleSheet("QGroupBox { font-weight: bold; }")
            grp_layout = QVBoxLayout(grp)
            grp_layout.setContentsMargins(4, 8, 4, 4)
            grp_layout.setSpacing(2)

            for tool_id in tools:
                btn = QPushButton(TOOL_LABELS.get(tool_id, tool_id))
                btn.setFixedHeight(BTN_H)
                btn.setCheckable(True)
                btn.setIconSize(BTN_ICON)

                icon_file = os.path.join(ICONS_DIR, TOOL_ICONS.get(tool_id, ""))
                if os.path.exists(icon_file):
                    btn.setIcon(QIcon(icon_file))

                # color de borde según tipo
                if tool_id in CONDITION_TOOLS:
                    border_color = "#1e5799"
                else:
                    border_color = "#7a1a1a"

                btn.setStyleSheet(
                    f"QPushButton {{ text-align:left; padding-left:6px; "
                    f"border-left: 4px solid {border_color}; border-radius:3px; }}"
                    f"QPushButton:checked {{ background:#dce8ff; border-left:4px solid #2962ff; }}"
                )
                btn.clicked.connect(lambda checked, t=tool_id, b=btn: self._on_tool_click(t, b))
                grp_layout.addWidget(btn)
                self._buttons[tool_id] = btn

            content_layout.addWidget(grp)

        content_layout.addStretch()
        scroll.setWidget(content)
        root_layout.addWidget(scroll)

        # ── Botón cursor / limpiar selección ──────────────────────
        self._cursor_btn = QPushButton("✖  Cancelar herramienta")
        self._cursor_btn.setFixedHeight(34)
        self._cursor_btn.setStyleSheet(
            "background:#e0e0e0; font-weight:bold; border-top:1px solid #bbb;"
        )
        self._cursor_btn.clicked.connect(self._clear_tool)
        root_layout.addWidget(self._cursor_btn)

        # ── Etiqueta de herramienta activa ────────────────────────
        self._active_label = QLabel("  Sin herramienta")
        self._active_label.setFixedHeight(24)
        self._active_label.setStyleSheet(
            "background:#f0f4ff; color:#555; font-style:italic; font-size:11px;"
        )
        root_layout.addWidget(self._active_label)

    # ─── Slots ──────────────────────────────────────────────────
    def _on_tool_click(self, tool_id: str, btn: QPushButton):
        # desmarcar todos
        for b in self._buttons.values():
            b.setChecked(False)
        if self._active_tool == tool_id:
            # segundo click = deseleccionar
            self._active_tool = None
            self._active_label.setText("  Sin herramienta")
            self.tool_selected.emit("")
        else:
            self._active_tool = tool_id
            btn.setChecked(True)
            self._active_label.setText(f"  ► {TOOL_LABELS.get(tool_id, tool_id)}")
            self.tool_selected.emit(tool_id)

    def _clear_tool(self):
        for b in self._buttons.values():
            b.setChecked(False)
        self._active_tool = None
        self._active_label.setText("  Sin herramienta")
        self.tool_selected.emit("")

    def current_tool(self) -> str:
        return self._active_tool or ""
