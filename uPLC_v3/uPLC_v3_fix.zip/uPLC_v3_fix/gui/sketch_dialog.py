#==================================================================
# uPLC_v3/gui/sketch_dialog.py - ETI Patagonia - prof.martintorres@educ.ar
#==================================================================

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton,
    QPlainTextEdit, QLabel, QApplication,
)
from PyQt5.QtGui import QFont, QColor
from PyQt5.QtCore import Qt


class SketchDialog(QDialog):
    """
    Ventana de vista previa del sketch Arduino generado.
    Permite copiar al portapapeles o cerrar.
    """

    def __init__(self, sketch_code: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("uPLCv3 — Sketch Arduino Generado")
        self.setMinimumSize(760, 580)
        self.setModal(True)

        layout = QVBoxLayout(self)
        layout.setSpacing(8)

        # ── Cabecera ──────────────────────────────────────────────
        hdr = QLabel("📄  Sketch listo para copiar al Arduino IDE:")
        hdr.setStyleSheet("font-weight: bold; font-size: 13px; color: #1a3a6b;")
        layout.addWidget(hdr)

        # ── Editor de texto (solo lectura, con syntax hint) ───────
        self.editor = QPlainTextEdit()
        self.editor.setReadOnly(True)
        self.editor.setPlainText(sketch_code)
        self.editor.setFont(QFont("Courier New", 10))
        self.editor.setStyleSheet(
            "background:#1e1e2e; color:#cdd6f4; border-radius:4px;"
            "selection-background-color:#45475a;"
        )
        self.editor.setLineWrapMode(QPlainTextEdit.NoWrap)
        layout.addWidget(self.editor)

        # ── Botones ───────────────────────────────────────────────
        btn_row = QHBoxLayout()

        btn_copy = QPushButton("📋  Copiar todo al portapapeles")
        btn_copy.setFixedHeight(36)
        btn_copy.setStyleSheet(
            "background:#1e88e5; color:white; border-radius:4px;"
            "font-size:13px; font-weight:bold;"
        )
        btn_copy.clicked.connect(self._copy_all)
        btn_row.addWidget(btn_copy)

        btn_close = QPushButton("Cerrar")
        btn_close.setFixedHeight(36)
        btn_close.setFixedWidth(100)
        btn_close.clicked.connect(self.accept)
        btn_row.addWidget(btn_close)

        layout.addLayout(btn_row)

        self._status_label = QLabel("")
        self._status_label.setAlignment(Qt.AlignCenter)
        self._status_label.setStyleSheet("color: green; font-weight: bold;")
        layout.addWidget(self._status_label)

    def _copy_all(self):
        QApplication.clipboard().setText(self.editor.toPlainText())
        self._status_label.setText("✅  Código copiado. Pegá en el Arduino IDE (Ctrl+V).")
