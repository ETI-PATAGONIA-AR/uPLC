#==================================================================
# uPLC_v3/generator/sketch_builder.py - ETI Patagonia - prof.martintorres@educ.ar
#==================================================================

from config.constants import (
    NO, NC, ADC, CMP_GT, CMP_LT, CMP_EQ,
    COIL, COIL_NC, PWM, TON, TOFF, SET_VAR,
    AND_A, AND_B, OR_A, OR_B, JUNCTION_TOOLS,
    MAX_COND,
)
from config.pins import DIGITAL_INPUTS, DIGITAL_OUTPUTS, ANALOG_INPUTS


# ─── Expresión de una celda de condición ────────────────────────

def _cond_expr(cell):
    """
    Convierte una CellData de condición en expresión C++ booleana.
    Retorna None si la celda está vacía, es un junction o no tiene ref.
    """
    tool, ref, val = cell.tool, cell.ref, cell.value

    # Junctions son visuales, no generan código
    if not tool or tool in JUNCTION_TOOLS:
        return None
    if not ref:
        return None

    if tool == NO:
        if ref.startswith("T") and ref[1:].isdigit():
            return f"_T{ref[1:]}_done"
        return ref

    if tool == NC:
        if ref.startswith("T") and ref[1:].isdigit():
            return f"(!_T{ref[1:]}_done)"
        return f"(!{ref})"

    if tool == ADC:
        return f"({ref} > 0)"

    if tool == CMP_GT:
        rhs = val if val else "0"
        return f"({ref} > {rhs})"

    if tool == CMP_LT:
        rhs = val if val else "255"
        return f"({ref} < {rhs})"

    if tool == CMP_EQ:
        rhs = val if val else "0"
        return f"({ref} == {rhs})"

    return None


# ─── Tipo de junction entre dos ramas consecutivas ──────────────

def _junction_op(rung, bi):
    """
    Determina el operador lógico que une branch[bi] con branch[bi+1].
    Retorna "&&" si hay AND_A/AND_B en la misma columna, "||" en caso contrario.
    """
    if bi + 1 >= len(rung.branches):
        return "||"
    br_a = rung.branches[bi]
    br_b = rung.branches[bi + 1]
    for col in range(MAX_COND):
        ta = br_a.cells[col].tool
        tb = br_b.cells[col].tool
        if ta == AND_A and tb == AND_B:
            return "&&"
        if ta == OR_A and tb == OR_B:
            return "||"
    return "||"  # default: OR


# ─── Expresión completa de un rung ──────────────────────────────

def _build_rung_expr(rung):
    """
    Construye la expresión C++ booleana del rung completo.
    - Las celdas de una misma rama se unen con &&  (AND en serie)
    - Las ramas se unen con || u &&  según el tipo de junction detectado
      ( OR_A/OR_B → || )  ( AND_A/AND_B → && )
    """
    # Expresión por rama (ignorando junction cells)
    branch_exprs = []
    for branch in rung.branches:
        parts = []
        for cell in branch.cells:
            if cell.is_empty() or cell.tool in JUNCTION_TOOLS:
                continue
            expr = _cond_expr(cell)
            if expr:
                parts.append(expr)
        branch_exprs.append("(" + " && ".join(parts) + ")" if parts else None)

    # Filtrar ramas vacías
    valid = [(i, e) for i, e in enumerate(branch_exprs) if e is not None]
    if not valid:
        return "false"
    if len(valid) == 1:
        return valid[0][1]

    # Combinar ramas de izquierda a derecha respetando el junction
    result = valid[0][1]
    for k in range(1, len(valid)):
        prev_bi = valid[k - 1][0]
        expr    = valid[k][1]
        op      = _junction_op(rung, prev_bi)
        result  = f"({result} {op} {expr})"

    return result


# ─── Auto-detección de fuente ADC en el rung ────────────────────

def _find_adc_source(rung):
    """
    Si el rung tiene una condición ADC, retorna su ref (ej: "A0").
    Usado para auto-asignar fuente al PWM cuando el valor está vacío.
    """
    for branch in rung.branches:
        for cell in branch.cells:
            if cell.tool == ADC and cell.ref:
                return cell.ref
    return None


# ─── Recolección de timers usados ───────────────────────────────

def _collect_timers(model):
    timers = {}
    for rung in model.rungs:
        out = rung.output
        if out.tool in (TON, TOFF) and out.ref:
            timers[out.ref] = {
                "type":   out.tool,
                "preset": out.value if out.value else "1000",
            }
    return timers


# ─── Generador principal ─────────────────────────────────────────

def build_sketch(model) -> str:
    used_timers = _collect_timers(model)
    lines = []

    # ── Cabecera ─────────────────────────────────────────────────
    lines += [
        "// ================================================================",
        "// uPLCv2 — Sketch generado automáticamente",
        "// ETI Patagonia - prof.martintorres@educ.ar",
        f"// Proyecto: {model.project_name}",
        "// ================================================================",
        "",
        "// HARDWARE: Arduino NANO",
        "// Entradas  → I1=D2  I2=D4  I3=D5  I4=D6  I5=D7  I6=D8  I7=D9",
        "// Salidas   → Q1=D14 Q2=D15 Q3=D16 Q4=D17 Q5=D3(PWM)",
        "// Analógicas→ A0=A6  A1=A7  (resolución 10 bits, mapeada a 0-255)",
        "// Display LCD→ I2C en A4(SDA) y A5(SCL) - Dirección 0x27",
        "",
        "#include <Wire.h>",
        "#include <LiquidCrystal_I2C.h>",
        "",
        "// Display LCD 20x4 I2C (dirección 0x27)",
        "LiquidCrystal_I2C lcd(0x27, 20, 4);",
        "",
    ]

    # ── Variables globales ────────────────────────────────────────
    lines.append("// === Bits de Memoria (M0..M9) ===")
    lines.append("bool " + ", ".join(f"M{i} = false" for i in range(10)) + ";")
    lines.append("")

    lines.append("// === Variables de 8 bits (V0..V9) ===")
    lines.append("uint8_t " + ", ".join(f"V{i} = 0" for i in range(10)) + ";")
    lines.append("")

    lines.append("// === Estados de Salidas Digitales ===")
    lines.append("bool Q1=false, Q2=false, Q3=false, Q4=false;")
    lines.append("uint8_t Q5 = 0;")
    lines.append("")

    if used_timers:
        lines.append("// === Temporizadores ===")
        for ref, info in used_timers.items():
            n = ref[1:]
            lines.append(f"unsigned long _T{n}_start = 0;")
            lines.append(f"bool _T{n}_done = false;")
            if info["type"] == TOFF:
                lines.append(f"bool _T{n}_prev_in = false;")
                lines.append(f"unsigned long _T{n}_off_t = 0;")
        lines.append("")

    # ── setup() ──────────────────────────────────────────────────
    lines.append("void setup() {")
    lines.append("  Serial.begin(9600);")
    lines.append("")
    lines.append("  // Inicializar LCD I2C")
    lines.append("  lcd.init();")
    lines.append("  lcd.backlight();")
    lines.append("  lcd.clear();")
    lines.append("")
    lines.append("  // Entradas digitales")
    for name, pin in DIGITAL_INPUTS.items():
        lines.append(f"  pinMode({pin}, INPUT);  // {name}")
    lines.append("")
    lines.append("  // Salidas digitales")
    for name, pin in DIGITAL_OUTPUTS.items():
        lines.append(f"  pinMode({pin}, OUTPUT); // {name}")
    lines.append("}")
    lines.append("")

    # ── loop() ───────────────────────────────────────────────────
    lines.append("void loop() {")
    lines.append("")

    lines.append("  // === Leer Entradas Digitales ===")
    for name, pin in DIGITAL_INPUTS.items():
        lines.append(f"  bool {name} = digitalRead({pin}); // D{pin}")
    lines.append("")

    lines.append("  // === Leer Entradas Analógicas (mapeadas 0-255) ===")
    for name, apin in ANALOG_INPUTS.items():
        lines.append(
            f"  uint8_t {name} = (uint8_t)map(analogRead({apin}), 0, 1023, 0, 255);"
        )
    lines.append("")

    # ── Lógica Ladder ─────────────────────────────────────────────
    lines.append("  // === Lógica Ladder ===")
    lines.append("")

    for rung_idx, rung in enumerate(model.rungs):
        label = rung.comment if rung.comment else f"Rung {rung_idx + 1}"
        lines.append(f"  // [{rung_idx + 1}] {label}")

        rung_expr = _build_rung_expr(rung)
        rv = f"_r{rung_idx}"
        lines.append(f"  bool {rv} = {rung_expr};")

        out = rung.output
        if out.is_empty():
            pass

        elif out.tool == COIL:
            lines.append(f"  {out.ref} = {rv};")

        elif out.tool == COIL_NC:
            lines.append(f"  {out.ref} = (!{rv});")

        elif out.tool == TON:
            n = out.ref[1:]
            preset = out.value if out.value else "1000"
            lines += [
                f"  if ({rv}) {{",
                f"    if (_T{n}_start == 0) _T{n}_start = millis();",
                f"    _T{n}_done = (millis() - _T{n}_start >= {preset}UL);",
                f"  }} else {{",
                f"    _T{n}_start = 0;",
                f"    _T{n}_done = false;",
                f"  }}",
            ]

        elif out.tool == TOFF:
            n = out.ref[1:]
            preset = out.value if out.value else "1000"
            lines += [
                f"  if ({rv}) {{",
                f"    _T{n}_done = true;",
                f"    _T{n}_prev_in = true;",
                f"  }} else if (_T{n}_prev_in) {{",
                f"    _T{n}_prev_in = false;",
                f"    _T{n}_off_t = millis();",
                f"  }} else {{",
                f"    _T{n}_done = (millis() - _T{n}_off_t < {preset}UL);",
                f"  }}",
            ]

        elif out.tool == PWM:
            # Si hay valor explícito (ej: "A0", "V3", "128") → usarlo
            # Si está vacío y hay fuente ADC en el rung → auto-pasar el ADC al PWM
            # Si está vacío y no hay ADC → 255 (encendido completo)
            val = out.value
            if not val:
                val = _find_adc_source(rung) or "255"
            lines += [
                f"  if ({rv}) Q5 = {val};",
                f"  else      Q5 = 0;",
            ]

        elif out.tool == SET_VAR:
            ref = out.ref if out.ref else "V0"
            val = out.value if out.value else None
            # Si no hay valor explícito, buscar ADC en el rung
            if not val:
                val = _find_adc_source(rung) or "0"
            lines.append(f"  if ({rv}) {ref} = {val};")

        lines.append("")

    # ── Escritura de salidas ──────────────────────────────────────
    lines.append("  // === Escribir Salidas ===")
    for name in ["Q1", "Q2", "Q3", "Q4"]:
        pin = DIGITAL_OUTPUTS[name]
        lines.append(f"  digitalWrite({pin}, {name}); // {name}")
    lines.append(f"  analogWrite({DIGITAL_OUTPUTS['Q5']}, Q5); // Q5 PWM")
    lines.append("")
    
    # ── Actualización del Display LCD ─────────────────────────────
    lines.append("  // === Actualizar Display LCD ===")
    lines.append("  lcd.clear();")
    lines.append("")
    lines.append("  // Línea 0: Labels de entradas")
    lines.append("  lcd.setCursor(0, 0);")
    lines.append("  lcd.print(\"I1 2 3 4 5 6 7 A0\");")
    lines.append("  lcd.setCursor(18, 0);")
    lines.append("  lcd.print(A0, DEC);")
    lines.append("")
    lines.append("  // Línea 1: Estados de entradas")
    lines.append("  lcd.setCursor(0, 1);")
    lines.append("  lcd.print(\" \");")
    lines.append("  lcd.print(I1?\"1\":\"0\"); lcd.print(\" \");")
    lines.append("  lcd.print(I2?\"1\":\"0\"); lcd.print(\" \");")
    lines.append("  lcd.print(I3?\"1\":\"0\"); lcd.print(\" \");")
    lines.append("  lcd.print(I4?\"1\":\"0\"); lcd.print(\" \");")
    lines.append("  lcd.print(I5?\"1\":\"0\"); lcd.print(\" \");")
    lines.append("  lcd.print(I6?\"1\":\"0\"); lcd.print(\" \");")
    lines.append("  lcd.print(I7?\"1\":\"0\");")
    lines.append("  lcd.setCursor(15, 1);")
    lines.append("  lcd.print(\"A1\");")
    lines.append("  lcd.setCursor(17, 1);")
    lines.append("  lcd.print(A1, DEC);")
    lines.append("")
    lines.append("  // Línea 2: Labels de salidas")
    lines.append("  lcd.setCursor(0, 2);")
    lines.append("  lcd.print(\"Q1 2 3 4 5    PWM\");")
    lines.append("  lcd.setCursor(17, 2);")
    lines.append("  uint8_t duty = map(Q5, 0, 255, 0, 100);")
    lines.append("  lcd.print(duty, DEC);")
    lines.append("")
    lines.append("  // Línea 3: Estados de salidas")
    lines.append("  lcd.setCursor(0, 3);")
    lines.append("  lcd.print(\" \");")
    lines.append("  lcd.print(Q1?\"1\":\"0\"); lcd.print(\" \");")
    lines.append("  lcd.print(Q2?\"1\":\"0\"); lcd.print(\" \");")
    lines.append("  lcd.print(Q3?\"1\":\"0\"); lcd.print(\" \");")
    lines.append("  lcd.print(Q4?\"1\":\"0\"); lcd.print(\" \");")
    lines.append("  lcd.print((Q5>0)?\"1\":\"0\");")
    lines.append("")
    lines.append("  delay(100); // Refresco del display")
    lines.append("}")
    lines.append("")

    return "\n".join(lines)
