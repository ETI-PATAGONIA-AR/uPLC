#==================================================================
# uPLC_v3/core/model.py - ETI Patagonia - prof.martintorres@educ.ar
#==================================================================

from config.constants import MAX_COND, CELL_H, COMMENT_H


class CellData:
    """Una celda: condición simple, mitad de junction, o vacía."""
    def __init__(self, tool="", ref="", value=""):
        self.tool  = tool
        self.ref   = ref
        self.value = value

    def is_empty(self):
        return not self.tool

    def to_dict(self):
        return {"tool": self.tool, "ref": self.ref, "value": self.value}

    @classmethod
    def from_dict(cls, d):
        return cls(
            tool  = d.get("tool",  ""),
            ref   = d.get("ref",   ""),
            value = d.get("value", ""),
        )


class BranchData:
    """Rama horizontal = AND de celdas."""
    def __init__(self):
        self.cells = [CellData() for _ in range(MAX_COND)]

    def to_dict(self):
        return {"cells": [c.to_dict() for c in self.cells]}

    @classmethod
    def from_dict(cls, d):
        obj = cls()
        raw = d.get("cells", [])
        for i, cd in enumerate(raw[:MAX_COND]):
            obj.cells[i] = CellData.from_dict(cd)
        return obj

    def is_empty(self):
        return all(c.is_empty() for c in self.cells)


class RungData:
    """Rung = N ramas en OR + una salida."""
    def __init__(self):
        self.branches = [BranchData()]
        self.output   = CellData()
        self.comment  = ""

    def pixel_height(self):
        return COMMENT_H + len(self.branches) * CELL_H

    def to_dict(self):
        return {
            "branches": [b.to_dict() for b in self.branches],
            "output":   self.output.to_dict(),
            "comment":  self.comment,
        }

    @classmethod
    def from_dict(cls, d):
        obj = cls()
        branches = d.get("branches", [])
        if branches:
            obj.branches = [BranchData.from_dict(b) for b in branches]
        obj.output  = CellData.from_dict(d.get("output", {}))
        obj.comment = d.get("comment", "")
        return obj


class LadderModel:
    """Modelo completo del programa PLC."""
    def __init__(self):
        self.rungs:        list = []
        self.project_name: str  = "Sin Nombre"

    def add_rung(self):
        r = RungData()
        self.rungs.append(r)
        return r

    def insert_rung(self, after_idx: int):
        r = RungData()
        self.rungs.insert(after_idx + 1, r)
        return r

    def delete_rung(self, idx: int):
        if 0 <= idx < len(self.rungs):
            self.rungs.pop(idx)

    def add_branch(self, rung_idx: int):
        if 0 <= rung_idx < len(self.rungs):
            b = BranchData()
            self.rungs[rung_idx].branches.append(b)
            return b
        return None

    def insert_branch_after(self, rung_idx: int, bi: int):
        """Inserta rama nueva justo después de bi."""
        if 0 <= rung_idx < len(self.rungs):
            b = BranchData()
            self.rungs[rung_idx].branches.insert(bi + 1, b)
            return b
        return None

    def delete_branch(self, rung_idx: int, branch_idx: int):
        rung = self.rungs[rung_idx]
        if len(rung.branches) > 1 and 0 <= branch_idx < len(rung.branches):
            rung.branches.pop(branch_idx)

    def to_dict(self):
        return {
            "project_name": self.project_name,
            "rungs":        [r.to_dict() for r in self.rungs],
        }

    @classmethod
    def from_dict(cls, d):
        m = cls()
        m.project_name = d.get("project_name", "Sin Nombre")
        m.rungs = [RungData.from_dict(r) for r in d.get("rungs", [])]
        return m
