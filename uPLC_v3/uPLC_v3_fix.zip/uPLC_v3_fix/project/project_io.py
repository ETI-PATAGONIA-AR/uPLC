#==================================================================
# uPLC_v3/project/project_io.py - ETI Patagonia - prof.martintorres@educ.ar
#==================================================================

import json
import os
from core.model import LadderModel
from generator.sketch_builder import build_sketch


def save_project(model: LadderModel, path: str) -> bool:
    """
    Guarda el proyecto completo:
    1. Crea carpeta con el nombre del proyecto
    2. Guarda el archivo .uplc (JSON) dentro de la carpeta
    3. Genera y guarda el archivo .ino (sketch Arduino) dentro de la carpeta
    Retorna True si tuvo éxito.
    """
    try:
        # Obtener nombre base y directorio
        base_dir = os.path.dirname(path)
        project_name = os.path.splitext(os.path.basename(path))[0]
        
        # Crear carpeta del proyecto
        project_folder = os.path.join(base_dir, project_name)
        os.makedirs(project_folder, exist_ok=True)
        
        # Guardar archivo .uplc
        uplc_path = os.path.join(project_folder, f"{project_name}.uplc")
        data = model.to_dict()
        with open(uplc_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        # Generar y guardar archivo .ino
        ino_path = os.path.join(project_folder, f"{project_name}.ino")
        sketch_code = build_sketch(model)
        with open(ino_path, "w", encoding="utf-8") as f:
            f.write(sketch_code)
        
        print(f"[project_io] Proyecto guardado en: {project_folder}")
        print(f"[project_io] - {project_name}.uplc")
        print(f"[project_io] - {project_name}.ino")
        return True
    except Exception as e:
        print(f"[project_io] Error al guardar: {e}")
        return False


def load_project(path: str):
    """Carga un modelo desde un archivo JSON. Retorna LadderModel o None."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return LadderModel.from_dict(data)
    except Exception as e:
        print(f"[project_io] Error al cargar: {e}")
        return None


def project_name_from_path(path: str) -> str:
    """Extrae el nombre del proyecto desde la ruta del archivo."""
    return os.path.splitext(os.path.basename(path))[0]
