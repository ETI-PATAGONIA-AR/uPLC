#==================================================================
# uPLC_v3/main.py - ETI Patagonia - prof.martintorres@educ.ar
#==================================================================

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt
from gui.main_window import MainWindow


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("uPLCv3")
    app.setOrganizationName("ETI Patagonia")
    app.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    app.setStyle("Fusion")

    win = MainWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
