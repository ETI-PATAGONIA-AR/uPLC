// ================================================================
// uPLCv2 — Sketch generado automáticamente
// ETI Patagonia - prof.martintorres@educ.ar
// Proyecto: ControlTEMPERATURA
// ================================================================

// HARDWARE: Arduino NANO
// Entradas  → I1=D2  I2=D4  I3=D5  I4=D6  I5=D7  I6=D8  I7=D9
// Salidas   → Q1=D14 Q2=D15 Q3=D16 Q4=D17 Q5=D3(PWM)
// Analógicas→ A0=A6  A1=A7  (resolución 10 bits, mapeada a 0-255)
// Display LCD→ I2C en A4(SDA) y A5(SCL) - Dirección 0x27

#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// Display LCD 20x4 I2C (dirección 0x27)
LiquidCrystal_I2C lcd(0x27, 20, 4);

// === Bits de Memoria (M0..M9) ===
bool M0 = false, M1 = false, M2 = false, M3 = false, M4 = false, M5 = false, M6 = false, M7 = false, M8 = false, M9 = false;

// === Variables de 8 bits (V0..V9) ===
uint8_t V0 = 0, V1 = 0, V2 = 0, V3 = 0, V4 = 0, V5 = 0, V6 = 0, V7 = 0, V8 = 0, V9 = 0;

// === Estados de Salidas Digitales ===
bool Q1=false, Q2=false, Q3=false, Q4=false;
uint8_t Q5 = 0;

void setup() {
  Serial.begin(9600);

  // Inicializar LCD I2C
  lcd.init();
  lcd.backlight();
  lcd.clear();

  // Entradas digitales
  pinMode(2, INPUT);  // I1
  pinMode(4, INPUT);  // I2
  pinMode(5, INPUT);  // I3
  pinMode(6, INPUT);  // I4
  pinMode(7, INPUT);  // I5
  pinMode(8, INPUT);  // I6
  pinMode(9, INPUT);  // I7

  // Salidas digitales
  pinMode(14, OUTPUT); // Q1
  pinMode(15, OUTPUT); // Q2
  pinMode(16, OUTPUT); // Q3
  pinMode(17, OUTPUT); // Q4
  pinMode(3, OUTPUT); // Q5
}

void loop() {

  // === Leer Entradas Digitales ===
  bool I1 = digitalRead(2); // D2
  bool I2 = digitalRead(4); // D4
  bool I3 = digitalRead(5); // D5
  bool I4 = digitalRead(6); // D6
  bool I5 = digitalRead(7); // D7
  bool I6 = digitalRead(8); // D8
  bool I7 = digitalRead(9); // D9

  // === Leer Entradas Analógicas (mapeadas 0-255) ===
  uint8_t A0 = (uint8_t)map(analogRead(A6), 0, 1023, 0, 255);
  uint8_t A1 = (uint8_t)map(analogRead(A7), 0, 1023, 0, 255);

  // === Lógica Ladder ===

  // [1] Relay MAESTRO
  bool _r0 = (I1);
  M0 = _r0;

  // [2] Set TEMPERATURA
  bool _r1 = ((A0 > 0));
  if (_r1) V0 = A0;

  // [3] Sensor TEMPERATURA
  bool _r2 = ((A1 > 0));
  if (_r2) V1 = A1;

  // [4] Señal para ENCENDER CALDERA
  bool _r3 = (M0 && (V1 < V0));
  M1 = _r3;

  // [5] Señal para APAGAR CALDERA
  bool _r4 = ((V1 > V0));
  M2 = _r4;

  // [6] Control de POTENCIA
  bool _r5 = ((M1) && ((!M2)));
  Q1 = _r5;

  // === Escribir Salidas ===
  digitalWrite(14, Q1); // Q1
  digitalWrite(15, Q2); // Q2
  digitalWrite(16, Q3); // Q3
  digitalWrite(17, Q4); // Q4
  analogWrite(3, Q5); // Q5 PWM

  // === Actualizar Display LCD ===
  lcd.clear();

  // Línea 0: Labels de entradas
  lcd.setCursor(0, 0);
  lcd.print("I1 2 3 4 5 6 7 A0");
  lcd.setCursor(17, 0);
  lcd.print(A0, DEC);

  // Línea 1: Estados de entradas
  lcd.setCursor(0, 1);
  lcd.print(" ");
  lcd.print(I1?"1":"0"); lcd.print(" ");
  lcd.print(I2?"1":"0"); lcd.print(" ");
  lcd.print(I3?"1":"0"); lcd.print(" ");
  lcd.print(I4?"1":"0"); lcd.print(" ");
  lcd.print(I5?"1":"0"); lcd.print(" ");
  lcd.print(I6?"1":"0"); lcd.print(" ");
  lcd.print(I7?"1":"0");
  lcd.setCursor(15, 1);
  lcd.print("A1");
  lcd.setCursor(17, 1);
  lcd.print(A1, DEC);

  // Línea 2: Labels de salidas
  lcd.setCursor(0, 2);
  lcd.print("Q1 2 3 4 5    PWM");
  lcd.setCursor(17, 2);
  uint8_t duty = map(Q5, 0, 255, 0, 100);
  lcd.print(duty, DEC);

  // Línea 3: Estados de salidas
  lcd.setCursor(0, 3);
  lcd.print(" ");
  lcd.print(Q1?"1":"0"); lcd.print(" ");
  lcd.print(Q2?"1":"0"); lcd.print(" ");
  lcd.print(Q3?"1":"0"); lcd.print(" ");
  lcd.print(Q4?"1":"0"); lcd.print(" ");
  lcd.print((Q5>0)?"1":"0");

  delay(900); // Refresco del display
}
