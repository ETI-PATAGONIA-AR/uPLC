@echo off
REM ==============================================================
REM uPLC_v3/run_uPLCv3.bat - ETI Patagonia - prof.martintorres@educ.ar
REM ==============================================================
cd /d %~dp0
python main.py
pause
