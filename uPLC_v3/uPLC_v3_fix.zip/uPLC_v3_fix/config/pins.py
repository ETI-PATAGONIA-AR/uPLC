#==================================================================
# uPLC_v3/config/pins.py - ETI Patagonia - prof.martintorres@educ.ar
#==================================================================

# ─── Entradas Digitales ────────────────────────────────────────
DIGITAL_INPUTS = {
    "I1": 2,    # D2  — interrupción posible (INT0)
    "I2": 4,    # D4
    "I3": 5,    # D5
    "I4": 6,    # D6
    "I5": 7,    # D7
    "I6": 8,    # D8
    "I7": 9,    # D9
}

# ─── Salidas Digitales ─────────────────────────────────────────
DIGITAL_OUTPUTS = {
    "Q1": 14,   # D14 / A0 — opto-relay
    "Q2": 15,   # D15 / A1 — opto-relay
    "Q3": 16,   # D16 / A2 — opto-relay
    "Q4": 17,   # D17 / A3 — opto-relay
    "Q5": 3,    # D3  — PWM / opto-MOSFET
}

# ─── Entradas Analógicas ───────────────────────────────────────
# A6 y A7 son pines solo-analógicos en el Arduino Nano
ANALOG_INPUTS = {
    "A0": "A6",  # pin analógico A6 (D20)
    "A1": "A7",  # pin analógico A7 (D21)
}
