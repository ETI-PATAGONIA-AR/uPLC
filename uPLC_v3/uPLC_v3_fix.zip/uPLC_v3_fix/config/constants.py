#==================================================================
# uPLC_v3/config/constants.py - ETI Patagonia - prof.martintorres@educ.ar
#==================================================================

# ─── Tool IDs — Condiciones ─────────────────────────────────────
NO      = "NO"       # Contacto Normalmente Abierto
NC      = "NC"       # Contacto Normalmente Cerrado
ADC     = "ADC"      # Entrada analógica como condición (>0)
CMP_GT  = "CMP_GT"   # Variable/Analógica > Valor
CMP_LT  = "CMP_LT"   # Variable/Analógica < Valor
CMP_EQ  = "CMP_EQ"   # Variable/Analógica == Valor

# ─── Tool IDs — Salidas ─────────────────────────────────────────
COIL    = "COIL"     # Bobina Normalmente Abierta
COIL_NC = "COIL_NC"  # Bobina Normalmente Cerrada
PWM     = "PWM"      # Salida PWM (Q5)
TON     = "TON"      # Timer On-Delay
TOFF    = "TOFF"     # Timer Off-Delay
SET_VAR = "SET_VAR"  # Asignar valor a Variable

# ─── Tool IDs — Junctions duales ────────────────────────────────
# El usuario selecciona OR_JCT o AND_JCT del Toolbox.
# Al hacer clic en (branch N, col C):
#   → coloca OR_A / AND_A  en branch N    (mitad superior — el bloque con etiqueta)
#   → coloca OR_B / AND_B  en branch N+1  (mitad inferior — el bracket)
#   → si branch N+1 no existe, se crea automáticamente
OR_JCT  = "OR_JCT"   # Herramienta selector (no se almacena en modelo)
AND_JCT = "AND_JCT"  # Herramienta selector (no se almacena en modelo)

# Mitades internas (SÍ se almacenan en el modelo)
OR_A  = "OR_A"
OR_B  = "OR_B"
AND_A = "AND_A"
AND_B = "AND_B"

# ─── Conjuntos ──────────────────────────────────────────────────
CONDITION_TOOLS = {NO, NC, ADC, CMP_GT, CMP_LT, CMP_EQ,
                   OR_A, OR_B, AND_A, AND_B}
OUTPUT_TOOLS    = {COIL, COIL_NC, PWM, TON, TOFF, SET_VAR}
JUNCTION_TOPS   = {OR_A, AND_A}
JUNCTION_BOTS   = {OR_B, AND_B}
JUNCTION_TOOLS  = JUNCTION_TOPS | JUNCTION_BOTS
# Herramientas que el usuario puede poner manualmente desde el Toolbox
# (las _B se auto-colocan, no se colocan manualmente)
USER_PLACEABLE_COND = {NO, NC, ADC, CMP_GT, CMP_LT, CMP_EQ}

# ─── Toolbox layout ─────────────────────────────────────────────
TOOLBOX_CATEGORIES = [
    ("Contactos",      [NO, NC]),
    ("Comparadores",   [ADC, CMP_GT, CMP_LT, CMP_EQ]),
    ("Conexiones",     [OR_JCT, AND_JCT]),
    ("Salidas",        [COIL, COIL_NC, PWM]),
    ("Temporizadores", [TON, TOFF]),
    ("Variables",      [SET_VAR]),
]

TOOL_LABELS = {
    NO:      "Contacto NA",
    NC:      "Contacto NC",
    ADC:     "Entrada ADC",
    CMP_GT:  "Var > Val",
    CMP_LT:  "Var < Val",
    CMP_EQ:  "Var = Val",
    OR_JCT:  "OR  (paralelo)",
    AND_JCT: "AND (serie dual)",
    COIL:    "Bobina",
    COIL_NC: "Bobina NC",
    PWM:     "Salida PWM",
    TON:     "Timer TON",
    TOFF:    "Timer TOFF",
    SET_VAR: "Asignar Var",
}

TOOL_ICONS = {
    NO:      "In_NA.png",
    NC:      "In_NC.png",
    ADC:     "In_ADC.png",
    CMP_GT:  "Fun_varMAYORvar.png",
    CMP_LT:  "Fun_varMENORvar.png",
    CMP_EQ:  "Fun_varIGUALvar.png",
    OR_JCT:  "Fun_OR_A.png",    # preview en toolbox
    AND_JCT: "Fun_AND_A.png",   # preview en toolbox
    OR_A:    "Fun_OR_A.png",
    OR_B:    "Fun_OR_B.png",
    AND_A:   "Fun_AND_A.png",
    AND_B:   "Fun_AND_B.png",
    COIL:    "Out_NA.png",
    COIL_NC: "Out_NC.png",
    PWM:     "Fun_PWM.png",
    TON:     "Fun_Ton.png",
    TOFF:    "Fun_Toff.png",
    SET_VAR: "Fun_varMAP.png",
}

# ─── Refs válidos por herramienta ───────────────────────────────
_INPUTS   = [f"I{i}" for i in range(1, 8)]
_MEMORIES = [f"M{i}" for i in range(10)]
_TIMERS   = [f"T{i}" for i in range(10)]
_OUTPUTS  = [f"Q{i}" for i in range(1, 5)]
_ANALOGS  = ["A0", "A1"]
_VARS     = [f"V{i}" for i in range(10)]

VALID_REFS = {
    NO:      _INPUTS + _MEMORIES + _TIMERS,
    NC:      _INPUTS + _MEMORIES + _TIMERS,
    ADC:     _ANALOGS,
    CMP_GT:  _VARS + _ANALOGS,
    CMP_LT:  _VARS + _ANALOGS,
    CMP_EQ:  _VARS + _ANALOGS,
    OR_A: [], OR_B:  [],
    AND_A:[], AND_B: [],
    COIL:    _OUTPUTS + _MEMORIES,
    COIL_NC: _OUTPUTS + _MEMORIES,
    PWM:     ["Q5"],
    TON:     _TIMERS,
    TOFF:    _TIMERS,
    SET_VAR: _VARS,
}

_CONST_VALS = [str(v) for v in [0, 8, 16, 32, 48, 64, 80, 96, 112, 128, 144, 160, 192, 224, 255]]

VALUE_OPTIONS = {
    CMP_GT:  _VARS + _ANALOGS + _CONST_VALS,
    CMP_LT:  _VARS + _ANALOGS + _CONST_VALS,
    CMP_EQ:  _VARS + _ANALOGS + _CONST_VALS,
    PWM:     _VARS + _ANALOGS + _CONST_VALS,
    SET_VAR: _VARS + _ANALOGS + _CONST_VALS,
}

# ─── Geometría del canvas ───────────────────────────────────────
CELL_W       = 88
CELL_H       = 72
MAX_COND     = 6
COMMENT_H    = 24
RAIL_X       = 20
LEFT_MARGIN  = 52
OUTPUT_X_OFF = 18
OUTPUT_W     = 88
TOP_MARGIN   = 20
RUNG_GAP     = 32
ADD_BTN_H    = 36

RIGHT_RAIL_X = LEFT_MARGIN + MAX_COND * CELL_W + OUTPUT_X_OFF + OUTPUT_W + 14
CANVAS_W     = RIGHT_RAIL_X + 30

# ─── Colores ────────────────────────────────────────────────────
C_RAIL       = (45,  45,  160)
C_WIRE       = (20,  20,  20)
C_GRID       = (200, 210, 230)
C_NO_BORDER  = (30,  30,  180)
C_NC_BORDER  = (160, 20,  20)
C_ADC_BORDER = (0,   120, 0)
C_CMP_BORDER = (160, 80,  0)
C_COIL_BG    = (230, 230, 255)
C_COIL_BD    = (30,  30,  180)
C_TON_BG     = (220, 255, 220)
C_TON_BD     = (0,   140, 0)
C_TOFF_BG    = (220, 255, 240)
C_TOFF_BD    = (0,   120, 80)
C_PWM_BG     = (255, 220, 220)
C_PWM_BD     = (160, 0,   0)
C_VAR_BG     = (245, 220, 255)
C_VAR_BD     = (120, 0,   140)
C_SELECTED   = (255, 30,  30)
C_COMMENT    = (245, 248, 235)
C_EMPTY_CELL = (235, 238, 245)
C_ADDBTN_BG  = (230, 240, 255)
